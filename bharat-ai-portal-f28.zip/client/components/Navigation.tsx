import { Link, useNavigate } from "react-router-dom";
import { useState, useRef, useEffect } from "react";
import { Globe, LogOut, Settings, Sun, Moon } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import { Language, getTranslation } from "@/lib/translations";
import { useAuth } from "@/lib/AuthContext";
import { useTheme } from "@/lib/ThemeContext";

export default function Navigation({ showAuth = true }: { showAuth?: boolean }) {
  const { language, setLanguage } = useLanguage();
  const { user, isGuest, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [showSettings, setShowSettings] = useState(false);
  const settingsRef = useRef<HTMLDivElement>(null);

  const languageOptions: { code: Language; label: string; name: string }[] = [
    { code: "en", label: "English", name: "English" },
    { code: "hi", label: "हिन्दी", name: "Hindi" },
    { code: "ta", label: "தமிழ்", name: "Tamil" },
  ];

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
  };

  // Close settings dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) {
        setShowSettings(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    navigate("/landing");
    setShowSettings(false);
  };

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="w-10 h-10 bg-gradient-to-br from-card-blue to-card-blue-dark rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">⚡</span>
            </div>
            <span className="font-bold text-lg text-foreground hidden sm:inline">
              {getTranslation(language, "nav.appName")}
            </span>
          </Link>

          {/* Center - Auth Buttons (if not authenticated) */}
          {showAuth && !user && (
            <div className="hidden md:flex items-center gap-3">
              <button
                onClick={() => navigate("/landing")}
                className="px-4 py-2 text-foreground hover:text-card-blue font-semibold transition-colors"
              >
                🔐 Login
              </button>
              <button
                onClick={() => navigate("/landing")}
                className="px-4 py-2 text-foreground hover:text-card-green font-semibold transition-colors"
              >
                ✍️ Sign Up
              </button>
              <button
                onClick={() => {
                  // This will trigger guest login from landing page
                  navigate("/landing");
                }}
                className="px-4 py-2 text-foreground hover:text-slate-400 font-semibold transition-colors"
              >
                👤 Guest
              </button>
            </div>
          )}

          {/* Right Side - Settings + Language + User Info */}
          <div className="flex items-center gap-4">
            {/* User Info & Logout (when authenticated) */}
            {showAuth && user && (
              <div className="hidden sm:flex items-center gap-3">
                <span className="text-sm text-foreground font-medium">
                  {isGuest ? "👤 Guest" : `👤 ${user.name}`}
                </span>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1 px-3 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm font-medium"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </div>
            )}

            {/* Settings Dropdown */}
            <div className="relative" ref={settingsRef}>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 hover:bg-muted rounded-lg transition-colors"
                title="Settings"
              >
                <Settings className="w-5 h-5 text-foreground" />
              </button>

              {/* Settings Menu */}
              {showSettings && (
                <div className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-lg shadow-lg p-2 z-50">
                  {/* Language Section */}
                  <div className="mb-3 pb-3 border-b border-border">
                    <p className="text-xs font-semibold text-muted-foreground px-3 py-2 uppercase">
                      Language
                    </p>
                    <div className="space-y-1">
                      {languageOptions.map((option) => (
                        <button
                          key={option.code}
                          onClick={() => {
                            handleLanguageChange(option.code);
                            setShowSettings(false);
                          }}
                          className={`w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                            language === option.code
                              ? "bg-card-blue text-white"
                              : "text-foreground hover:bg-muted"
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Theme Section */}
                  <div className="mb-3 pb-3 border-b border-border">
                    <p className="text-xs font-semibold text-muted-foreground px-3 py-2 uppercase">
                      Theme
                    </p>
                    <button
                      onClick={() => {
                        toggleTheme();
                        setShowSettings(false);
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 rounded text-sm text-foreground hover:bg-muted transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        {theme === "light" ? (
                          <Sun className="w-4 h-4" />
                        ) : (
                          <Moon className="w-4 h-4" />
                        )}
                        {theme === "light" ? "Light" : "Dark"}
                      </span>
                      <span className="text-xs opacity-60">
                        {theme === "light" ? "☀️" : "🌙"}
                      </span>
                    </button>
                  </div>

                  {/* Logout Button (mobile) */}
                  {user && (
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      Logout
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
