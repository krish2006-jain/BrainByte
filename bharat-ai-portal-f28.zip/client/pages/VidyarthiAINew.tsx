"use client";

import { useState, useRef, useEffect } from "react";
import { Upload, X, Send, Loader2, FileText, Search, Plus, Grid2X2, MoreVertical } from "lucide-react";
import Navigation from "@/components/Navigation";

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  type: string;
}

interface Message {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
}

interface OutputType {
  id: string;
  title: string;
  icon: string;
  description: string;
  emoji: string;
}

const outputTypes: OutputType[] = [
  { id: "mindmap", title: "Mind Map", icon: "🗺️", emoji: "🗺️", description: "Visual map of concepts" },
  { id: "report", title: "Reports", icon: "📊", emoji: "📊", description: "Detailed analysis" },
  { id: "flashcards", title: "Flashcards", icon: "📇", emoji: "📇", description: "Quiz yourself" },
  { id: "quiz", title: "Quiz", icon: "❓", emoji: "❓", description: "Test your knowledge" },
];

export default function VidyarthiAINew() {
  const [sources, setSources] = useState<UploadedFile[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [selectedOutput, setSelectedOutput] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [searchSources, setSearchSources] = useState("");

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach((file) => {
        const validTypes = ["application/pdf", "image/jpeg", "image/png", "text/plain"];
        if (!validTypes.includes(file.type)) {
          alert("Please upload PDF, JPG, PNG, or TXT files");
          return;
        }

        const newFile: UploadedFile = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          size: file.size,
          type: file.type,
        };
        setSources((prev) => [...prev, newFile]);
      });
      // Clear input
      event.target.value = "";
    }
  };

  const handleRemoveSource = (id: string) => {
    setSources((prev) => prev.filter((f) => f.id !== id));
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || sources.length === 0) return;

    const userMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: Math.random().toString(36).substr(2, 9),
        type: "ai",
        content: `Based on your uploaded materials, here's an analysis of your query: "${inputValue}". This is a simulated response that would contain detailed insights extracted from your sources with proper context and citations.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1500);
  };

  const handleGenerateOutput = async (outputType: string) => {
    if (sources.length === 0) {
      alert("Please add sources first");
      return;
    }

    setSelectedOutput(outputType);
    setIsLoading(true);

    // Simulate generation
    setTimeout(() => {
      const output = getOutputContent(outputType);
      const aiMessage: Message = {
        id: Math.random().toString(36).substr(2, 9),
        type: "ai",
        content: output,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);
      setIsLoading(false);
      setSelectedOutput(null);
    }, 2000);
  };

  const getOutputContent = (type: string): string => {
    const contents: { [key: string]: string } = {
      mindmap: `📊 MIND MAP\n\nMain Topic\n├── Concept 1\n│   ├── Sub-concept 1a\n│   └── Sub-concept 1b\n├── Concept 2\n│   ├── Sub-concept 2a\n│   └── Sub-concept 2b\n└── Concept 3\n    └── Sub-concepts...`,
      report: `📄 DETAILED REPORT\n\nExecutive Summary\n• Key finding 1\n• Key finding 2\n\nMain Sections\n1. Introduction & Background\n2. Core Concepts & Themes\n3. Analysis & Insights\n4. Practical Applications\n5. Conclusion & Next Steps`,
      flashcards: `📇 FLASHCARDS\n\nCard 1: What is the main concept?\nAnswer: Definition and explanation here\n\nCard 2: How does this apply?\nAnswer: Real-world examples and use cases\n\nCard 3: What are the key terms?\nAnswer: Definitions of important vocabulary`,
      quiz: `❓ QUIZ\n\n1. Question 1\n   a) Option A\n   b) Option B\n   c) Option C\n   d) Option D\n\n2. Question 2\n   (Multiple choice options...)\n\n3. Question 3\n   (True/False questions...)\n\nStart the quiz to test your knowledge!`,
    };
    return contents[type] || "Content generation in progress...";
  };

  const filteredSources = sources.filter((source) =>
    source.name.toLowerCase().includes(searchSources.toLowerCase())
  );

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="flex h-[calc(100vh-64px)]">
        {/* Left Sidebar - Sources */}
        <div className="w-64 bg-card border-r border-border flex flex-col">
          {/* Header */}
          <div className="p-6 border-b border-border">
            <h2 className="text-lg font-bold text-foreground mb-4">Sources</h2>

            {/* Add Sources Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-card-blue hover:bg-blue-600 text-white font-semibold transition-colors mb-4"
            >
              <Plus className="w-5 h-5" />
              Add sources
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              onChange={handleFileUpload}
              className="hidden"
              accept=".pdf,.txt,.jpg,.jpeg,.png"
            />

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search sources..."
                value={searchSources}
                onChange={(e) => setSearchSources(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-card-blue"
              />
            </div>
          </div>

          {/* Sources List */}
          <div className="flex-1 overflow-y-auto p-4">
            {filteredSources.length > 0 ? (
              <div className="space-y-3">
                {filteredSources.map((source) => (
                  <div
                    key={source.id}
                    className="flex items-start gap-3 p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors group"
                  >
                    <FileText className="w-5 h-5 text-card-blue flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {source.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatFileSize(source.size)}
                      </p>
                    </div>
                    <button
                      onClick={() => handleRemoveSource(source.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-background rounded"
                    >
                      <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="w-8 h-8 mx-auto mb-3 opacity-50" />
                <p className="text-sm">No sources added yet</p>
                <p className="text-xs mt-1">Click "Add sources" to begin</p>
              </div>
            )}
          </div>

          {/* Footer Info */}
          {sources.length > 0 && (
            <div className="p-4 border-t border-border text-xs text-muted-foreground text-center">
              {sources.length} source{sources.length !== 1 ? "s" : ""} added
            </div>
          )}
        </div>

        {/* Right Panel - Chat */}
        <div className="flex-1 flex flex-col bg-background">
          {/* Header */}
          <div className="border-b border-border px-8 py-6 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-foreground">Chat</h1>
            <button className="p-2 hover:bg-muted rounded-lg transition-colors">
              <Grid2X2 className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-8">
            {sources.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <Upload className="w-16 h-16 text-muted-foreground/30 mb-6" />
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Add a source to get started
                </h2>
                <p className="text-muted-foreground mb-8 max-w-md">
                  Upload documents, PDFs, or text files to start analyzing and generating insights
                </p>

                {/* Output Type Options */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-2xl">
                  {outputTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => {
                        if (sources.length > 0) {
                          handleGenerateOutput(type.id);
                        }
                      }}
                      className="p-6 rounded-lg bg-card-blue/10 hover:bg-card-blue/20 border border-card-blue/30 transition-all text-center"
                    >
                      <div className="text-4xl mb-3">{type.emoji}</div>
                      <p className="font-semibold text-foreground">{type.title}</p>
                    </button>
                  ))}
                </div>

                <p className="text-sm text-muted-foreground mt-8">
                  Upload a source to get started • 0 sources
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xl p-4 rounded-lg ${
                        msg.type === "user"
                          ? "bg-card-blue text-white"
                          : "bg-muted text-foreground border border-border"
                      }`}
                    >
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">
                        {msg.content}
                      </p>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-muted border border-border p-4 rounded-lg flex items-center gap-3">
                      <Loader2 className="w-4 h-4 animate-spin text-card-blue" />
                      <span className="text-sm text-muted-foreground">Generating...</span>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          {/* Input Area */}
          {sources.length > 0 && (
            <>
              {/* Output Type Buttons */}
              <div className="border-t border-border px-8 py-4 flex gap-2 overflow-x-auto">
                {outputTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => handleGenerateOutput(type.id)}
                    disabled={isLoading}
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card-blue/10 hover:bg-card-blue/20 border border-card-blue/30 text-sm font-medium text-foreground whitespace-nowrap transition-colors disabled:opacity-50"
                  >
                    <span>{type.emoji}</span>
                    {type.title}
                  </button>
                ))}
              </div>

              {/* Study Partner Bar */}
              <div className="border-t border-border px-8 py-6 bg-card-blue/5">
                <div className="max-w-2xl">
                  <h3 className="font-bold text-foreground mb-3">YOUR STUDY PARTNER</h3>
                  <p className="text-sm text-foreground leading-relaxed mb-2">
                    AI Study Partner is a smart companion that helps you with studies, answers questions, and explains concepts anytime. 📚
                  </p>
                  <p className="text-sm text-foreground leading-relaxed mb-2">
                    It also provides motivation and emotional support when you're feeling low or stressed. 💪
                  </p>
                  <p className="text-sm text-foreground">
                    Available 24/7. It ensures you never have to study or face challenges alone. 👥
                  </p>
                </div>
              </div>

              {/* Message Input */}
              <div className="border-t border-border p-6">
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                    placeholder="Ask something about your sources..."
                    className="flex-1 px-4 py-3 bg-muted border border-border rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-card-blue"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={isLoading || !inputValue.trim()}
                    className="px-4 py-3 bg-card-blue hover:bg-blue-600 disabled:bg-muted text-white rounded-lg transition-colors flex items-center justify-center"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
