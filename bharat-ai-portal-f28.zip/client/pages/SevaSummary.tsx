import SevaSummaryNew from "./SevaSummaryNew";

export default function SevaSummary() {
  return <SevaSummaryNew />;
}
