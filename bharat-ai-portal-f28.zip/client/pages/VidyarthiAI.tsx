import VidyarthiAINew from "./VidyarthiAINew";

export default function VidyarthiAI() {
  return <VidyarthiAINew />;
}
