import { useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import { useLanguage } from "@/lib/LanguageContext";
import { getTranslation } from "@/lib/translations";

const NotFound = () => {
  const location = useLocation();
  const { language } = useLanguage();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-md">
          <h1 className="text-6xl sm:text-7xl font-bold text-foreground mb-4">
            404
          </h1>
          <p className="text-xl sm:text-2xl text-muted-foreground mb-2">
            Oops! Page not found
          </p>
          <p className="text-muted-foreground mb-8">
            The page you're looking for doesn't exist.
          </p>
          <Link
            to="/"
            className="inline-block bg-card-blue hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-lg transition-all"
          >
            {getTranslation(language, "common.backToHome")}
          </Link>
        </div>
      </div>

      <footer className="border-t border-border bg-card py-6 sm:py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-muted-foreground text-sm sm:text-base">
          <p>{getTranslation(language, "footer.copyright")}</p>
        </div>
      </footer>
    </div>
  );
};

export default NotFound;
