import SarkariDostNew from "./SarkariDostNew";

export default function SarkariDost() {
  return <SarkariDostNew />;
}
