"use client";

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import Navigation from "@/components/Navigation";

type AuthMode = "initial" | "login" | "signup";

export default function Landing() {
  const { login, signup, guestLogin } = useAuth();
  const navigate = useNavigate();
  const [authMode, setAuthMode] = useState<AuthMode>("initial");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setIsLoading(true);

    try {
      await signup(name, email, password);
      navigate("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Signup failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuest = () => {
    guestLogin();
    // Navigate to home directly for guest users
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-blue-900 to-slate-900">
      <Navigation showAuth={false} />

      <div className="pt-20 px-4 sm:px-6 lg:px-8 pb-12">
        <div className="max-w-6xl mx-auto">
          {authMode === "initial" ? (
            <>
              {/* Hero Section */}
              <div className="text-center mb-20">
                <h1 className="text-5xl sm:text-6xl font-bold text-white mb-6">
                  🇮🇳 Bharat AI Portal
                </h1>
                <p className="text-xl sm:text-2xl text-blue-200 mb-8">
                  Your AI-Powered Assistant for Government Services & Education
                </p>

                {/* Features Overview */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
                  {/* Sarkari-Dost Card */}
                  <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-8 text-center hover:bg-white/20 transition-all">
                    <div className="text-5xl mb-4">🏛️</div>
                    <h3 className="text-2xl font-bold text-white mb-3">Sarkari-Dost</h3>
                    <p className="text-blue-200 mb-4">
                      Navigate government processes with ease. Get document checklists, step-by-step guides, and error scanning for applications.
                    </p>
                    <div className="text-sm text-slate-400">
                      ✓ Document Verification<br/>
                      ✓ Guided Instructions<br/>
                      ✓ Error Detection
                    </div>
                  </div>

                  {/* Seva-Summary Card */}
                  <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-8 text-center hover:bg-white/20 transition-all">
                    <div className="text-5xl mb-4">📊</div>
                    <h3 className="text-2xl font-bold text-white mb-3">Seva-Summary</h3>
                    <p className="text-blue-200 mb-4">
                      Upload government documents and let AI summarize, analyze, and answer your questions in real-time.
                    </p>
                    <div className="text-sm text-slate-400">
                      ✓ Document Upload<br/>
                      ✓ AI Analysis<br/>
                      ✓ Chat Interface
                    </div>
                  </div>

                  {/* Vidyarthi-AI Card */}
                  <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-8 text-center hover:bg-white/20 transition-all">
                    <div className="text-5xl mb-4">📚</div>
                    <h3 className="text-2xl font-bold text-white mb-3">Vidyarthi-AI</h3>
                    <p className="text-blue-200 mb-4">
                      Your AI study companion. Upload learning materials and get summaries, quizzes, and personalized insights.
                    </p>
                    <div className="text-sm text-slate-400">
                      ✓ Study Materials<br/>
                      ✓ AI Insights<br/>
                      ✓ Quiz Generation
                    </div>
                  </div>
                </div>

                {/* About Section */}
                <div className="bg-white/10 backdrop-blur border border-white/20 rounded-2xl p-12 mb-20">
                  <h2 className="text-3xl font-bold text-white mb-6">About Bharat AI Portal</h2>
                  <p className="text-blue-200 text-lg leading-relaxed max-w-3xl mx-auto">
                    Bharat AI Portal is a comprehensive platform designed to empower Indian citizens and students. 
                    Whether you need help navigating government services, analyzing documents, or learning new subjects, 
                    our AI-powered tools are here to make your life easier. 
                    All tools are available for free, and you can access them as a guest or by creating an account.
                  </p>
                </div>
              </div>

              {/* Auth Options */}
              <div className="flex flex-col sm:flex-row justify-center gap-6 mb-12">
                <button
                  onClick={() => setAuthMode("login")}
                  className="px-8 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all font-bold text-lg shadow-lg hover:shadow-xl"
                >
                  🔐 Login
                </button>
                <button
                  onClick={() => setAuthMode("signup")}
                  className="px-8 py-4 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all font-bold text-lg shadow-lg hover:shadow-xl"
                >
                  ✍️ Sign Up
                </button>
                <button
                  onClick={handleGuest}
                  className="px-8 py-4 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-all font-bold text-lg shadow-lg hover:shadow-xl"
                >
                  👤 Continue as Guest
                </button>
              </div>

              {/* Footer Info */}
              <div className="text-center text-slate-400 text-sm">
                <p>Created with ❤️ for empowering India with AI</p>
              </div>
            </>
          ) : (
            <>
              {/* Auth Forms */}
              <div className="max-w-md mx-auto">
                <button
                  onClick={() => setAuthMode("initial")}
                  className="mb-6 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-semibold"
                >
                  ← Back
                </button>

                <div className="bg-white rounded-2xl shadow-xl p-8">
                  <h2 className="text-3xl font-bold text-slate-800 mb-6 text-center">
                    {authMode === "login" ? "Login to Your Account" : "Create New Account"}
                  </h2>

                  {error && (
                    <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                      {error}
                    </div>
                  )}

                  <form
                    onSubmit={authMode === "login" ? handleLogin : handleSignup}
                    className="space-y-4"
                  >
                    {authMode === "signup" && (
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">
                          Full Name
                        </label>
                        <input
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Your name"
                          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Password
                      </label>
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••"
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>

                    {authMode === "signup" && (
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">
                          Confirm Password
                        </label>
                        <input
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="••••••"
                          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          required
                        />
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:bg-slate-400 transition-colors font-bold text-lg mt-6"
                    >
                      {isLoading
                        ? "Processing..."
                        : authMode === "login"
                        ? "Login"
                        : "Create Account"}
                    </button>
                  </form>

                  <p className="text-center text-slate-600 text-sm mt-6">
                    {authMode === "login" ? (
                      <>
                        Don't have an account?{" "}
                        <button
                          onClick={() => setAuthMode("signup")}
                          className="text-blue-500 hover:text-blue-700 font-semibold"
                        >
                          Sign up
                        </button>
                      </>
                    ) : (
                      <>
                        Already have an account?{" "}
                        <button
                          onClick={() => setAuthMode("login")}
                          className="text-blue-500 hover:text-blue-700 font-semibold"
                        >
                          Login
                        </button>
                      </>
                    )}
                  </p>

                  <button
                    onClick={() => {
                      handleGuest();
                      setAuthMode("initial");
                    }}
                    className="w-full py-3 bg-slate-200 text-slate-800 rounded-lg hover:bg-slate-300 transition-colors font-semibold mt-4"
                  >
                    or Continue as Guest
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
