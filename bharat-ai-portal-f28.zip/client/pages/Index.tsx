import { Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import Navigation from "@/components/Navigation";
import { FileText, Stethoscope, BookOpen, ArrowRight } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import { getTranslation } from "@/lib/translations";
import { useAuth } from "@/lib/AuthContext";

export default function Index() {
  const { language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Redirect to landing if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/landing");
    }
  }, [isAuthenticated, navigate]);

  const features = [
    {
      id: "sarkari-dost",
      titleKey: "features.sarkaridost.title",
      subtitleKey: "features.sarkaridost.subtitle",
      descriptionKey: "features.sarkaridost.description",
      icon: FileText,
      color: "from-card-blue to-blue-600",
      borderColor: "border-card-blue",
      buttonColor: "bg-card-blue hover:bg-blue-600",
      path: "/sarkari-dost",
    },
    {
      id: "seva-summary",
      titleKey: "features.sevasummary.title",
      subtitleKey: "features.sevasummary.subtitle",
      descriptionKey: "features.sevasummary.description",
      icon: Stethoscope,
      color: "from-card-green to-green-600",
      borderColor: "border-card-green",
      buttonColor: "bg-card-green hover:bg-green-600",
      path: "/seva-summary",
    },
    {
      id: "vidyarthi-ai",
      titleKey: "features.vidyarthi.title",
      subtitleKey: "features.vidyarthi.subtitle",
      descriptionKey: "features.vidyarthi.description",
      icon: BookOpen,
      color: "from-card-orange to-orange-600",
      borderColor: "border-card-orange",
      buttonColor: "bg-card-orange hover:bg-orange-600",
      path: "/vidyarthi-ai",
    },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navigation />

      {/* Hero Section */}
      <section className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="max-w-4xl mx-auto w-full text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-4 leading-tight">
            {getTranslation(language, "home.hero.title")}
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            {getTranslation(language, "home.hero.subtitle")}
          </p>

          {/* Feature Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <Link
                  key={feature.id}
                  to={feature.path}
                  className="group"
                >
                  <div className="h-full bg-card border border-border rounded-2xl p-6 sm:p-8 hover:border-card-blue/50 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl flex flex-col">
                    {/* Icon Container */}
                    <div className={`w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-gradient-to-br ${feature.color} mb-6 flex items-center justify-center`}>
                      <Icon className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                    </div>

                    {/* Content */}
                    <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2 text-left">
                      {getTranslation(language, feature.titleKey)}
                    </h2>
                    <p className="text-sm sm:text-base text-card-blue font-semibold mb-3 text-left">
                      {getTranslation(language, feature.subtitleKey)}
                    </p>
                    <p className="text-muted-foreground text-left text-sm sm:text-base mb-6 flex-1">
                      {getTranslation(language, feature.descriptionKey)}
                    </p>

                    {/* Button */}
                    <button className={`w-full py-3 px-4 rounded-lg font-semibold text-white ${feature.buttonColor} transition-all duration-200 flex items-center justify-center gap-2 group/btn`}>
                      {getTranslation(language, "common.getStarted")}
                      <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-6 sm:py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-muted-foreground text-sm sm:text-base">
          <p>{getTranslation(language, "footer.copyright")}</p>
        </div>
      </footer>
    </div>
  );
}
